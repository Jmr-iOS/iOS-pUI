//
//  ViewController.swift
//  0_0 - UIView
//
//  URL(animations): http://www.raywenderlich.com/76200/basic-uiview-animation-swift-tutorial
//  URL(animations): http://www.raywenderlich.com/86521/how-to-make-a-view-controller-transition-animation-like-in-the-ping-app
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {

    var viewOne : UIView!;
    var viewTwo : UIView!;
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        gen_views();
        add_primary_tapResponse();
        pick_view(true);
        
        return;
    }
    
    
    func gen_views() {
        
        viewOne = UIView();
        viewOne.backgroundColor = UIColor.redColor();
        viewOne.frame = self.view.frame;

        addSecondUIView(viewOne, dispStr: "4:30 PM");
        addSubviewButton(viewOne, return_msg: "Launch View #1", action_fcn:  "press_launch:");

        viewTwo = UIView();
        viewTwo.backgroundColor = UIColor.blueColor();
        viewTwo.frame = self.view.frame;

        addSecondUIView(viewTwo, dispStr: "8:00 PM");
        addSubviewButton(viewTwo, return_msg: "Return from View #2", action_fcn:  "press_return:");

        viewOne.frame = self.view.frame;
        viewTwo.frame = CGRectMake(self.view.frame.width, 0, self.view.frame.width, self.view.frame.height);       //init off-screen
        
        self.view.addSubview(viewOne);                                    //add em both!
        self.view.addSubview(viewTwo);
        
        return;
    }
    

    func pick_view(showFirst: Bool) {

        let addedView   = (showFirst) ? viewOne : viewTwo;
        let removedView = (showFirst) ? viewTwo : viewOne;
      
        let xRemoved    = (showFirst) ? self.view.frame.width : -self.view.frame.width; // sets which dir it slides into view from
        
        addedView.alpha = 0;
        
        self.view.addSubview(addedView);
        
        print("old view off!");
        
        UIView.animateWithDuration(0.5, delay: 0.5, options: UIViewAnimationOptions.TransitionCrossDissolve, animations: {
            
            print("new view added");
            
            addedView.alpha = 1.0;
            
            addedView.frame = self.view.frame;
            
            }, completion: { (finished: Bool) -> Void in
                
                print("old view removed");
                
                removedView.frame = CGRectMake(xRemoved, 0, self.view.frame.width, self.view.frame.height);
                
                removedView.removeFromSuperview();
        })
        
        return;
    }
    
    
    func add_primary_tapResponse() {

        let tapGesture = UITapGestureRecognizer(target: self, action: Selector("myPrimaryTapResponse:"));
        
        tapGesture.delegate = self;
        
        self.view.addGestureRecognizer(tapGesture);
        
        return;
    }
    
    
    func addSecondUIView(aView: UIView, dispStr : String) {

        let anotherView : UIView = UIView(frame: CGRect(x: 20, y:60, width: 100, height: 50));
        
        anotherView.backgroundColor = UIColor.grayColor();
        
        anotherView.layer.cornerRadius = 15;

        let someLabel : UILabel = UILabel(frame: CGRect(x:5, y: 0, width: anotherView.frame.width, height:  anotherView.frame.height));
    
        someLabel.font  =   UIFont(name: "HelveticaNeue", size: 23);
        someLabel.text  =   dispStr;
        someLabel.textColor     = UIColor.whiteColor();
        someLabel.textAlignment = NSTextAlignment.Center;
    
        anotherView.addSubview(someLabel);
        
        aView.addSubview(anotherView);
    
        return;
    }
    
    
    func addSubviewButton(aView: UIView, return_msg: String, action_fcn : Selector) {
        
        let newButton : UIButton = UIButton(type: UIButtonType.RoundedRect);
        
        newButton.translatesAutoresizingMaskIntoConstraints = true;                     //must be true for center to work

        newButton.setTitle(return_msg,      forState: UIControlState.Normal);
        newButton.backgroundColor = UIColor.whiteColor();
        
        //newButton.frame = CGRectMake(0, 0, 144, 30);                                  // or just use sizeToFit(), it's easier!
        newButton.sizeToFit();
        newButton.center = CGPointMake((UIScreen.mainScreen().bounds.width)/2, 250);     //must call after it's sized or won't work!
        
        //actions
        newButton.addTarget(self, action: action_fcn, forControlEvents:  .TouchUpInside);
        
        //add!
        aView.addSubview(newButton);
        
        return;
    }
    
    /*
// Add tap gesture recognizer to View
let tapGesture = UITapGestureRecognizer(target: self, action: Selector("myMethodToHandleTap:"))
tapGesture.delegate = self
myView.addGestureRecognizer(tapGesture)
}

func myMethodToHandleTap(sender: UITapGestureRecognizer) {

let tappedView = sender.view as! UIView
// ...
}
*/

    func myPrimaryTapResponse(sender: UITapGestureRecognizer) {
        
        print("Bam here it is!!!!");
        let tappedView = sender.view as! UIView!;

        return;
    }
    
    
    func press_launch(sender: UIButton!) {

        print("\(sender.titleLabel!.text!) was pressed and press_launch called");

        pick_view(false);

        return;
    }

    
    func press_return(sender: UIButton!) {
        print("\(sender.titleLabel!.text!) was pressed and press_return called");
        
        pick_view(true);

        return;
    }

    
    override func didReceiveMemoryWarning() { super.didReceiveMemoryWarning(); }
}

