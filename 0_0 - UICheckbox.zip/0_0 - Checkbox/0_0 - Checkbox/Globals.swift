
import Foundation

enum switchState {
    case UNCHECKED, CHECKED, BOLD_CHECKED;
}