/************************************************************************************************************************************/
/** @file       main.m
 *  @project    0_0 - Empty Template (Obj C)
 *  @brief      x
 *  @details    x
 *
 *  @notes      x
 *
 *  @section    Opens
 *      none current
 *
 *  @section    Legal Disclaimer
 *      All contents of this source file and/or any other Jaostech related source files are the explicit property of Jaostech
 *      Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController


/************************************************************************************************************************************/
/** @fcn        (void)viewDidLoad
 *  @brief      x
 *  @details    x
 */
/************************************************************************************************************************************/
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.translatesAutoresizingMaskIntoConstraints = false;
    
    return;
}


/************************************************************************************************************************************/
/** @fcn        (void)didReceiveMemoryWarning
 *  @brief      x
 *  @details    x
 */
/************************************************************************************************************************************/
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

    return;
}

@end

