/************************************************************************************************************************************/
/** @file		NSCodingMeal.swift
 *	@project    0_0 - Data Storage
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/16/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 *  @url    (core) https://developer.apple.com/library/ios/referencelibrary/GettingStarted/DevelopiOSAppsSwift/Lesson10.html
 *              Note: The section 'Save and Load the Meal List' looks to be your solution!
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
 * 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit


struct Meal {
    var weight : Float  = 1234.56;
    var title  : String = "abcd";
    
    static var purpose : String = "To learn how to save data";      /* static indicates a property of the class, not the obj!       */
}


class NSCodingMeal : NSObject, NSCoding {
    
    var myMeal : Meal!;
    var myNum  : Int    = 12;
    var myName : String = "maybe";
    
    
    init(a  : Int, b : String, c : Float, d : String) {

        myMeal = Meal();
        
        myNum  = a;
        myName = b;

        myMeal.weight = c;
        myMeal.title  = d;
        
        super.init();

        return;
    }

                                                                                    /* Convention to always declare this MARK       */
//MARK: NSCoding
//**********************************************************************************************************************************//
//                                          NSCoding Protocol                                                                       //
//**********************************************************************************************************************************//
    //store
    func encodeWithCoder(aCoder: NSCoder) {

        //Meal
        aCoder.encodeFloat(self.myMeal.weight, forKey: "meal_weight");
        aCoder.encodeObject(self.myMeal.title, forKey: "meal_title");
        
        //Number (Int)
        aCoder.encodeInteger(self.myNum, forKey: "myNum");
        
        //Name (String)
        aCoder.encodeObject(self.myName, forKey: "myName");
        
        return;
    }


    //pull (retrieve)
    required convenience init?(coder aDecoder: NSCoder) {                           /* 'convenience' denotes that it must call standard designated init as well */
        
        /* "Here, you’re declaring this initializer as a convenience initializer
            because it only applies when there’s saved data to be loaded" 
        */
        
        let retrievedNum  = aDecoder.decodeIntegerForKey("myNum");//not needed  as! Int;
        let retrievedName = aDecoder.decodeObjectForKey("myName") as! String;
        

        let retrievedMealNum  = aDecoder.decodeFloatForKey("meal_weight"); //not needed as! Float;
        let retrievedMealName = aDecoder.decodeObjectForKey("meal_title") as! String;
        
        self.init(a: retrievedNum,
                  b: retrievedName,
                  c: retrievedMealNum,
                  d: retrievedMealName);

        return;
    }
}

