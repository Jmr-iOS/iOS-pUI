
import Foundation

enum switchState {
    case unchecked, checked, bold_CHECKED;
}
