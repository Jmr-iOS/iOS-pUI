//
//  ViewController.m
//  0_0 - Empty Template (Obj C)
//
//  Created by Justin Reina on 11/22/15.
//  Copyright © 2015 Jaostech. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.translatesAutoresizingMaskIntoConstraints = false;
    
    return;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

    return;
}

@end
