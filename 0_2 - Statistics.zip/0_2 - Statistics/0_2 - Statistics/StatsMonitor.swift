/************************************************************************************************************************************/
/** @file       StatsMonitor
 *  @project    0_2 - Statistics
 *  @brief      monitor statistic on phone
 *  @details    x
 *
 *  @section    Opens
 *              Print minutes to two digits (https://stackoverflow.com/questions/24051314/precision-string-format-specifier-in-swift)
 *              Print location
 *              DateFields properly initialized
 *
 *     @section    Legal Disclaimer
 *             All contents of this source file and/or any other Jaostech related source files are the explicit property on Jaostech
 *             Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
import Foundation
import UIKit

struct Location {
    let latitude: Double
    let longitude: Double
}

struct DateFields {
    var day   : Int?;
    var month : Int?;
    var year  : Int?;
    var hour  : Int?;
    var min   : Int?;
    var sec   : Int?;
    var merid : String?;
}

extension Int {
    func format(f: String) -> String {
        return String(format: "%\(f)d", self)
    }
}

class StatsMonitor : NSObject {
    
    var viewController : ViewController;

    /********************************************************************************************************************************/
    /** @fcn        init(viewController : ViewController)
     *  @brief      x
     *  @details    x
     *
     *  @param        [in] (ViewController) viewController - x
     *
     */
    /********************************************************************************************************************************/
    init(viewController : ViewController) {
        
        //Init
        self.viewController = viewController;
        super.init();
        
        return;
    }

    
    /********************************************************************************************************************************/
    /** @fcn        public class func getTime()
     *  @brief      get date in useable format
     *  @details    x
     *
     *  @param        [out] (DateFields) Current date in useable format
     *
     *  @section    Opens
     *      x
     */
    /********************************************************************************************************************************/
    public class func getTime() -> DateFields {

        let date = Date();
        
        var fields : DateFields = DateFields();
        
        //Get Date
        fields.day   = Calendar.current.component(.day,   from: date);
        fields.month = Calendar.current.component(.month, from: date);
        fields.year  = Calendar.current.component(.year,  from: date);
        
        //Get Time
        fields.hour = Calendar.current.component(.hour,   from: date);
        fields.min  = Calendar.current.component(.minute, from: date);
        fields.sec  = Calendar.current.component(.second, from: date);

        //Store Meridium
        fields = self.genMeridiem(date: fields);

        //Assemble
        let dayStr  : String = String(format:"Date: %i/%i/%i", fields.month!, fields.day!, fields.year!);
        let timeStr : String = String(format:"Time: %i:\(fields.min!.format(f: "02")) \(fields.merid!)", fields.hour!);

        //Print
        print(dayStr);
        print(timeStr);
        
//formating ref
        // let someInt = 4, someIntFormat = "03";
        // print("The integer number \(someInt) formatted with \"\(someIntFormat)\" looks like \(someInt.format(f: someIntFormat))")
        // The integer number 4 formatted with "03" looks like 004
        
        return fields;
    }
    
    
    /********************************************************************************************************************************/
    /** @fcn        public class func genMeridiem(date : DateFields) -> DateFields
     *  @brief      generate AM/PM, add value & update hours field
     *  @details    x
     *
     *  @param      [in] (DateFields) date - date to perform calculation on
     *  @return     date with meridiem applied
     *
     *  @assum      meridiem has not been calculated yet
     */
    /********************************************************************************************************************************/
    public class func genMeridiem(date : DateFields) -> DateFields {
    
        var newDate : DateFields = date;
        
        let hour = date.hour;
        
        if(hour! >= 12) {
            newDate.merid = "pm";                           /* store as PM for afternoon, else AM                                   */
            newDate.hour! -= 12;                            /* update to reflect merdiem                                            */
        } else {
            newDate.merid = "am";
        }
        
        return newDate;
    }
}

