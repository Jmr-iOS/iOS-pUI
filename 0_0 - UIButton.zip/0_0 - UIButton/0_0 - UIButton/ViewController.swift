//
//  ViewController.swift
//  0_0 - Empty Template (Swift)
//
//  URL: http://iphonedev.tv/blog/2014/1/22/programmatic-uibutton-on-ios-70-create-a-uibutton-with-code
//  URL: http://iphonedev.tv/blog/2014/8/4/create-a-uibutton-in-code-with-objective-c?utm_source=iPhoneDevtv&utm_medium=blog&utm_term=Button%20Tutorial&utm_campaign=ProgramaticUIButtoniOS7
//
//  todo - toggle control states it with a second button tap
//


import UIKit

class ViewController: UIViewController {

    var buttonOne:UIButton!;
    var buttonTwo:UIButton!;
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        let type:UIButtonType = UIButtonType.RoundedRect;     //(normal)
        //let type:UIButtonType = UIButtonType.System;
        
        //Buton Init
        buttonOne = UIButton(type: type);

        buttonOne.translatesAutoresizingMaskIntoConstraints = true;                     //must be true for center to work
        
        
        //Button Display Text
        buttonOne.setTitle("Test Button - Normal",      forState: UIControlState.Normal);
        buttonOne.setTitle("Test Button - Disabled",    forState: UIControlState.Disabled);
        buttonOne.setTitle("Test Button - Focused",     forState: UIControlState.Focused);
        buttonOne.setTitle("Test Button - Highlighted", forState: UIControlState.Highlighted);
        buttonOne.setTitle("Test Button - Selected",    forState: UIControlState.Selected);

        
        //Design
        buttonOne.backgroundColor = UIColor.greenColor();
        
        //placement & size
        buttonOne.sizeToFit();
        buttonOne.center = CGPointMake(self.view.center.x, 50);     //must call after it's sized or won't work!
        
        //actions
        buttonOne.addTarget(self, action: "pressed:", forControlEvents:  .TouchUpInside);
        
        //add!
        self.view.addSubview(buttonOne);
        
        self.addSecondButton();
        
        print("ViewController.viewDidLoad():       viewDidLoad() complete");
        
        return;
    }

    
    func pressed(sender: UIButton!) {
        
        sender.sizeToFit(); //adjust to new size! This kinda works. The true full solution is complicated, this shows how to get there...
        
        print("\(sender.titleLabel!.text!) was pressed");
        
        return;
    }
    
    
    /****************************************************/
    /* Second Button                                    */
    /****************************************************/
    func addSecondButton() {
       
        //Buton Init
        buttonTwo = UIButton(type: UIButtonType.RoundedRect);
        
        buttonTwo.translatesAutoresizingMaskIntoConstraints = true;                                  //must be true for center to work
        
        buttonTwo.setTitle("Second Button",      forState: UIControlState.Normal);

        //size & loc
        buttonTwo.sizeToFit();

        let newY : CGFloat = buttonOne.frame.origin.y + buttonOne.frame.height + (buttonTwo.frame.height/2);

        buttonTwo.center = CGPointMake(self.view.center.x, newY);

        buttonTwo.setBackgroundImage(UIImage(named:"greyButton"), forState: UIControlState.Normal);  //set image after sizeToFit() so it's sized to text and not the huge PNG!
        buttonTwo.setBackgroundImage(UIImage(named:"greenButton"), forState: UIControlState.Highlighted);
        
        buttonTwo.addTarget(self, action: "secondPressed:", forControlEvents:  .TouchUpInside);

        self.view.addSubview(buttonTwo);
        
        return;
    }
    
    
    func secondPressed(sender: UIButton!) {
        
        buttonOne.sizeToFit(); //adjust to new size! This one works!
        
        print("\(sender.titleLabel!.text!) was pressed");
        
        return;
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
        return;
    }
}



