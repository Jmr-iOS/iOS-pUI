/************************************************************************************************************************************/
/** @file       Globals.swift
 *  @project    0_0 - Checkbox
 *  @brief      x
 *  @details    x
 *
 *  @section    Opens
 *      none current
 *
 *  @section    Legal Disclaimer
 *      All contents of this source file and/or any other Jaostech related source files are the explicit property of Jaostech
 *      Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
import Foundation

enum switchState {
    case unchecked, checked, bold_CHECKED;
}
