//
//  ViewController.swift
//  0_0 - Empty Template (Swift)
//
//  Current Status: This shiznit doesn't work...?
//  Primary
//  URL: ? (swift)http://stackoverflow.com/questions/24520024/how-to-use-uilocalnotification-in-swift
//                    note - once works, post your answer here :O
//  URL: ? (objC) https://mobiarch.wordpress.com/2013/09/03/posting-a-message-in-ios-notification-center/
//
//  General Notifcations Stuff
//  URL: http://www.idev101.com/learn_iphone_programming.html
//  URL: http://www.idev101.com/code/Cocoa/Notifications.html
//  URL: http://developer.apple.com/library/mac/documentation/Cocoa/Conceptual/Notifications/Introduction/introNotifications.html#//apple_ref/doc/uid/10000043i


import UIKit

class ViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        optDemo_addButton(self.view);
        
        makeAMonsterousLabel(self.view);
        
        addNotification(self.view);
        
        print("ViewController.viewDidLoad():       viewDidLoad() complete?");
        
        return;
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
        
        return;
    }
    
    
    func addNotification(view:UIView) {
        
        print("Posting Notification");
        
        var notification = UILocalNotification();
        
        notification.timeZone = NSTimeZone.defaultTimeZone();
        
        let dateTime:NSDate = NSDate(timeIntervalSinceNow: 15);
        
        notification.fireDate = dateTime;
        
        notification.alertBody = "Test";
        
        UIApplication.sharedApplication().scheduleLocalNotification(notification);
        
        ScheduleLocalNotificationIfPossible();
        
        print("ViewController.addNotification():       addNotification() complete");
        
        return;
    }
    
    
  
    private let kLocalNotificationMessage:String = "Your message goes here!"
    private let kLocalNotificationTimeInterval:NSTimeInterval = 5
    
    private func LocalNotification() -> UILocalNotification {
        
        var localNotification:UILocalNotification = UILocalNotification();
        
        print("LocalNotifification was called");
        
        localNotification.fireDate = NSDate(timeIntervalSinceNow:kLocalNotificationTimeInterval);
        
        localNotification.alertBody = kLocalNotificationMessage;
        
        return localNotification;
    }
    
    private func ScheduleLocalNotificationIfPossible() {
        
        print("scheduleLocal was called");
        
    //    if (UIApplication.sharedApplication().isRegisteredForRemoteNotifications()) {
            
            UIApplication.sharedApplication().scheduleLocalNotification(LocalNotification())
            
            print("complete");
  //      }
        
        return;
    }
    

    
    
    
    
    func optDemo_addButton(view:UIView) {
        
        let button   = UIButton(type: UIButtonType.System) as UIButton;
        
        button.frame = CGRectMake(100, 100, 100, 50);
        
        button.backgroundColor = UIColor.greenColor()
        
        button.setTitle("Test Button", forState: UIControlState.Normal);
        
        button.addTarget(self, action: "myButton_response:", forControlEvents:  .TouchUpInside);
        
        view.addSubview(button);
        
        print("ViewController.optDemo_addButton(): Button added");
        
        return;
    }
    
    
    func makeAMonsterousLabel(view:UIView) {
        
        let myFirstLabel = UILabel();
        let myFirstButton = UIButton();
        
        myFirstLabel.text = "I made a label on the screen #toogood4you";
        myFirstLabel.font = UIFont(name: "MarkerFelt-Thin", size: 45);
        myFirstLabel.textColor = UIColor.redColor();
        myFirstLabel.textAlignment = .Center;
        myFirstLabel.numberOfLines = 5;
        
        myFirstLabel.frame = CGRectMake(15, 54, 300, 500);
        myFirstButton.setTitle("✸", forState: .Normal);
        myFirstButton.setTitleColor(UIColor.blueColor(), forState: .Normal);
        myFirstButton.frame = CGRectMake(15, 200, 300, 500);
        
        myFirstButton.addTarget(self, action: "pressed:", forControlEvents: .TouchUpInside);
        
        view.addSubview(myFirstLabel);
        view.addSubview(myFirstButton);
        
        return;
    }
    
    
    func pressed(sender: UIButton!) {
        let alertView = UIAlertView();
        alertView.addButtonWithTitle("Ok");
        alertView.title = "title";
        alertView.message = "message";
        alertView.show();
        
        return;
    }
    
    
    func myButton_response(sender: UIButton!) {
        
        print("Button Response fired. Game on!");
        
        return;
    }
}



