/************************************************************************************************************************************/
/** @file		DataBackup.swift
 *	@project    0_0 - NSCoding
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Vioteq
 * 	@created	1/23/16
 * 	@last rev	x
 *
 *
 * 	@notes		x
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
* 			All contents of this source file and/or any other Vioteq related source files are the explicit property on Vioteq
* 			Corporation. Do not distribute. Do not copy.   Copyright © 2016 Jaostech. All rights reserved.
 */
/************************************************************************************************************************************/
import UIKit


struct DataBackupKeys {
    static let num0 : String = "num0";
    static let num1 : String = "num1";
    static let str0 : String = "str0";
    static let str1 : String = "str1";
}


class DataBackup : NSObject, NSCoding {
    
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("name_of_app");

    var someNumber0 : Float;
    var someNumber1 : Float;
    var someString0 : String;
    var someString1 : String;
 
//MARK: Initialization
    init?(num0 : Float, num1 : Float, str0 : String, str1: String) {
        
        self.someNumber0 = num0;
        self.someNumber1 = num1;
        self.someString0 = str0;
        self.someString1 = str1;
        
        super.init();
        
        return;
    }


// MARK: NSCoding
    //store
    func encodeWithCoder(aCoder: NSCoder) {

        aCoder.encodeFloat(self.someNumber0, forKey:  DataBackupKeys.num0);
        aCoder.encodeFloat(self.someNumber1, forKey:  DataBackupKeys.num1);
        aCoder.encodeObject(self.someString0, forKey: DataBackupKeys.str0);
        aCoder.encodeObject(self.someString1, forKey: DataBackupKeys.str1);

        return;
    }


    //retrieve
    required convenience init?(coder aDecoder: NSCoder) {

        let num0 : Float?  = aDecoder.decodeFloatForKey(DataBackupKeys.num0);
        let num1 : Float?  = aDecoder.decodeFloatForKey(DataBackupKeys.num1);
        let str0 : String? = aDecoder.decodeObjectForKey(DataBackupKeys.str0) as? String;
        let str1 : String? = aDecoder.decodeObjectForKey(DataBackupKeys.str1) as? String;

        if(num0 != nil) {
            self.init(num0:num0!, num1:num1!, str0:str0!, str1:str1!);
        } else {
            self.init(num0:0, num1:0, str0: "", str1:"");
        }
        
        return;
    }


}

