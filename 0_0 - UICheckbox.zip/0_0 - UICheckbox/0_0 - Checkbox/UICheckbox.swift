//
//  UICheckBox.swift
//  0_0 - Checkbox
//
//  URL: http://stackoverflow.com/questions/2599451/cabasicanimation-delegate-for-animationdidstop
//

import UIKit

class UICheckbox: UIView {
    
    @objc var imageView : UIImageView!;

    @objc var uncheckedImage  :UIImage = UIImage(named:"anote_unchecked")!;
    @objc var checkedImage    :UIImage = UIImage(named:"anote_checked")!;
    
    @objc let loadDelay_s : Double = 0.05;
    
    @objc var loadThread : Timer!;
    @objc var fadeThread : Timer!;
    
    @objc var state: Bool = false;
    
    @objc init(view:UIView, xCoord:CGFloat, yCoord:CGFloat) {

        super.init(frame:CGRect(x: xCoord, y: yCoord, width: 40, height: 40));

        //image init
        imageView  = UIImageView();
        
        imageView.frame = CGRect(x: 0, y: 0, width: 40, height: 40);
        
        imageView.image = uncheckedImage;

        //handle taps
        self.addTapRecognizer();

        //uiview setup: me<-image then main<-main
        self.addSubview(imageView);
        view.addSubview(self);
        
        print("UICheckbox.init():                      complete");
        
        return;
    }


    @objc func addTapRecognizer() {
        
        let tapRecognizer : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UICheckbox.handleTap(_:)));
        
        tapRecognizer.numberOfTapsRequired    = 1;
        tapRecognizer.numberOfTouchesRequired = 1;
        
        self.addGestureRecognizer(tapRecognizer);
        self.isUserInteractionEnabled = true;
        
        return;
    }

    @objc func handleTap(_ recognizer:UITapGestureRecognizer) {
        
        //Swap w/Fade
        let fadeAnim:CABasicAnimation = CABasicAnimation(keyPath: "contents");
        
        fadeAnim.fromValue = (self.imageView.image == uncheckedImage) ? uncheckedImage:checkedImage;
        fadeAnim.toValue   = (self.imageView.image == uncheckedImage) ? checkedImage:uncheckedImage;
        
        fadeAnim.duration = loadDelay_s;
        
        fadeAnim.delegate = self as? CAAnimationDelegate;
        
        
        //Update ImageView & State
        state = (self.imageView.image == uncheckedImage) ? true : false;    //if it was unchecked, now it's checked, true!

        imageView.image = (self.imageView.image == uncheckedImage) ? checkedImage:uncheckedImage;
        
        imageView.layer.add(fadeAnim, forKey: "contents");

        
        //Handle the Click
        self.buttonClicked();
        
        return;
    }
    
    @objc func buttonClicked() {
        
        print("click - insert your handle code here!");
        
        return;
    }
    
    
//?    override func animationDidStop (_ anim: CAAnimation, finished flag: Bool) { return; }
//?    override func animationDidStart(_ anim: CAAnimation) { return; }
    
    
    required init?(coder aDecoder: NSCoder) { super.init(coder:aDecoder); }
}

