//
//  ViewController.swift
//  0_0 - Empty Template (Swift)
//
//  @url    https://developer.apple.com/library/ios/referencelibrary/GettingStarted/DevelopiOSAppsSwift/Lesson10.html
//
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    var nameField : UITextField = UITextField();
    var numField  : UITextField = UITextField();
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;
     
        self.genUI();
        
        print("ViewController.viewDidLoad():       viewDidLoad() complete");
        
        return;
    }

    
    func genUI() {
        
        //myName string
        self.nameField = UITextField(frame: CGRectMake(20, 50, 300, 40));
        self.nameField.placeholder = "entery myName here";
        self.nameField.keyboardType = .Default;
        self.nameField.delegate = self;
        
        self.view.addSubview(self.nameField);
        

        //myNum num
        self.numField = UITextField(frame: CGRectMake(20, 80, 300, 40));
        self.numField.placeholder = "entery myNum here";
        self.numField.keyboardType = .DecimalPad;
        self.numField.delegate = self;
        
        self.view.addSubview(self.numField);
        
        
        //(todo) myMeal struct


        //Return Button
        let returnButton : UIButton = UIButton(type: UIButtonType.RoundedRect);
        
        returnButton.setTitle("Return",      forState: UIControlState.Normal);
        returnButton.sizeToFit();
        returnButton.center = CGPointMake(45, 130);
        
        //actions
        returnButton.addTarget(self, action: "pressed:", forControlEvents:  .TouchUpInside);
        
        //add
        self.view.addSubview(returnButton);
        
    }


    func pressed(sender: UIButton!) {
        
        //return keyboard (assume it's up :)  )
        self.view.endEditing(true);
        sender.resignFirstResponder();           //not sure if this is required, but is often used so I'll use it too! not required though?

        
        let nameInput : String! = self.nameField.text;
        let numInput  : String! = self.numField.text;

        var myNewName  : String!;
        var myNewFloat : Float!;


        if(nameInput.characters.count > 0) {
            print("I retrieved '\(nameInput)'");
            
            myNewName = nameInput;
        }

        if(numInput.characters.count > 0) {

            let myFloat : Float = Float(numInput)!;
            
            print("I retrieved '\(myFloat)'");
            
            myNewFloat = myFloat;
        }
        

        if((myNewName != nil) && (myNewFloat != nil)) {

            print("i will store you");
            
            self.storeUsingNSCoding(Float(numInput)!, string: nameInput);
            
        } else {
            print("someone is nil");
        }
        
        
        return;
    }

    //important note: the CLASSES must conform to NSCoding. And a ViewController subclass cannot, create a new class for it!!
    func storeUsingNSCoding(number : Float, string : String) {

    
//        let newCoder : NSCoder = NSCoder
  //      newCoder.encodeFloat(number, forKey: "theNumber");
    //    newCoder.encodeObject(string, forKey: "theString");
      //  newCoder.finalize();
        
        return;
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();

        return;
    }
}

