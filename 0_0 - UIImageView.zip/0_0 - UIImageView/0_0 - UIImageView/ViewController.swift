//
//  ViewController.swift
//  0_0 - UIImageView
//
//  URL: http://stackoverflow.com/questions/11355671/how-do-i-implement-the-uitapgesturerecognizer-into-my-application
//  URL: https://developer.apple.com/library/ios/documentation/EventHandling/Conceptual/EventHandlingiPhoneOS/GestureRecognizer_basics/GestureRecognizer_basics.html
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        //#0 - Basic
        //self.loadImage(self.view, imageStr:"example");
        
        //#1 - Tap Handling
        self.view.addSubview(TappableImageView(frame:CGRectMake((375-200)/2, 25, 200, 200)));
        
        //#2 - Fade (swap)
        self.view.addSubview(TappableImageSwapView(frame:CGRectMake((375-100)/2, 235, 100, 100)));
        
        //#3 - Fade (general)
        self.view.addSubview(FadingImageView(frame:CGRectMake((375-200)/2, 350, 200, 200)));
        
        //#4 - Colored Image
        self.view.addSubview(self.getTintedImage());
            
        print("ViewController.viewDidLoad():       viewDidLoad() complete");
        
        return;
    }

    
    //the plain, simple load
    func loadImage(view:UIView, imageStr:String) {
        
        let width  : CGFloat = 206;
        let height : CGFloat = 190;
        let xCoord : CGFloat = 50;
        let yCoord : CGFloat = 200;
        
        var imageView : UIImageView;
        
        imageView  = UIImageView();
        
        imageView.frame = CGRectMake(xCoord, yCoord, width, height);
        
        imageView.image = UIImage(named:"example");
        
        view.addSubview(imageView);
        
        return;
    }
    
    
    //apply a color to an image
    //ref - http://stackoverflow.com/questions/28427935/how-can-i-change-image-tintcolor
    //ref - https://www.captechconsulting.com/blogs/ios-7-tutorial-series-tint-color-and-easy-app-theming
    func getTintedImage() -> UIImageView {
        
        var image     : UIImage;
        var imageView : UIImageView;
        
        image = UIImage(named: "empty")!;
        let size  : CGSize = image.size;
        let frame : CGRect = CGRectMake((UIScreen.mainScreen().bounds.width-86)/2, 600, size.width, size.height);
        
        let redCover : UIView = UIView(frame: frame);
        
        redCover.backgroundColor = UIColor.redColor();
        redCover.layer.opacity = 0.75;
        
        imageView       = UIImageView();
        imageView.image = image.imageWithRenderingMode(UIImageRenderingMode.Automatic);
        
        imageView.addSubview(redCover);
        
        return imageView;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();

        return;
    }
}

