//
//  main.m
//  0_0 - Empty Template (Obj C)
//
//  Created by Justin Reina on 11/22/15.
//  Copyright © 2015 Jaostech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
