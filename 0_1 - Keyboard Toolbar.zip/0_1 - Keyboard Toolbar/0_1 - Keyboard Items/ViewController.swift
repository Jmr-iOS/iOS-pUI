/************************************************************************************************************************************/
/** @file		ViewController.swift
 *  @project    0_1 - Keyboard Toolbar
 * 	@brief		x
 * 	@details	x
 *
 * 	@author		Justin Reina, Firmware Engineer, Jaostech
 * 	@created	5/20/15
 * 	@last rev	x
 *
 *
 * 	@notes		Source
 *                  url
 *
 * 	@section	Opens
 * 			none current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Jaostech related source files are the explicit property on Jaostech
 * 			Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    var textField : UITextField!;

    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;

        self.addTextField();
        self.addKeyboardItems();
        
        self.view.backgroundColor = UIColor.blueColor();
        
        print("ViewController.viewDidLoad():       viewDidLoad() complete");
        
        return;
    }

    var testBool : UISwitch!;
    
    func addKeyboardItems() {

        let tempLabel : UILabel = UILabel(frame: CGRectMake(0, 11, self.view.frame.width, 21));
        tempLabel.text = "Test Label";
        let barLabel : UIBarButtonItem = UIBarButtonItem(customView: tempLabel);
  
        //let space : UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: self, action: nil);
        
        testBool = UISwitch();
        let barBool  : UIBarButtonItem = UIBarButtonItem(customView: testBool);
        
        let toolbar : UIToolbar = UIToolbar(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, 40));

//(switch directly followed by label)
      let itemsArray = [barBool, barLabel];

//(if you want items stuck to left and right)
//      let itemsArray = [barLabel, space, barBool];
//no (bool doesn't appear)
//      let itemsArray = [barLabel, barBool];
//no (they are drawn on top of each other)
//      let itemsArray = [barBool, space, barLabel];
        
        
        toolbar.setItems(itemsArray, animated: false);
        
        textField.inputAccessoryView = toolbar;

        return;
    }
    
    
    func addTextField () {
        
        textField = UITextField(frame: CGRectMake(10, 30, 300, 40));
        
        textField.placeholder = "Enter text here, bitches!";
        textField.font = UIFont.systemFontOfSize(15);
        textField.borderStyle = UITextBorderStyle.RoundedRect;
        textField.autocorrectionType = UITextAutocorrectionType.No;
        textField.keyboardType = UIKeyboardType.Default;
        textField.returnKeyType = UIReturnKeyType.Done;
        textField.clearButtonMode = UITextFieldViewMode.WhileEditing;
        textField.contentVerticalAlignment = UIControlContentVerticalAlignment.Center;
        textField.delegate = self;
        
        textField.translatesAutoresizingMaskIntoConstraints = true;
        
        view.addSubview(textField);
        
        return;
    }

    
    //**********************************************************************************************************************************//
    //                                                       UITextFieldDelegate                                                        //
    //**********************************************************************************************************************************//
    func addDelegate(delegate : UITextFieldDelegate) {
        
        self.textField.delegate = self;                               /* be the delegate                                      */
        
        return;
    }
    
    
    func textFieldShouldReturn(textField : UITextField) -> Bool {
        
        textField.resignFirstResponder();                             /* here is the action which dismisses keyboard          */
        
        let resultStr : String = (self.testBool.on) ? "true" : "false";
        
        print("ViewController.textFieldShouldReturn():                  Keyboard Boolean: \(resultStr)");
        print("ViewController.textFieldShouldReturn():                  return key pressed and exiting");
        
        return true;                                                        /* normal behavior                                      */
    }
    
    
    func textFieldDidBeginEditing   (textField : UITextField) {
        print("TextField did begin editing method called");
        return;
    }
    
    func textFieldDidEndEditing     (textField : UITextField) {
        print("TextField did end editing method called");
        return;
    }
    
    func textFieldShouldBeginEditing(textField : UITextField) -> Bool {
        print("TextField should begin editing method called");
        return true;
    }
    
    func textFieldShouldClear(textField: UITextField) -> Bool {
        print("TextField should clear method called");
        return true;
    }
    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        print("TextField should snd editing method called");
        return true;
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        print("While entering the characters this method gets called");
        return true;
    }


    override func didReceiveMemoryWarning() { super.didReceiveMemoryWarning(); }
}



