//
//  AppDelegate.h
//  0_0 - Empty Template (Obj C)
//
//  Created by Justin Reina on 11/22/15.
//  Copyright © 2015 Jaostech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

