//
//  ViewController.swift
//  0_0 - UITableView
//
//  URL:  http://viperxgames.blogspot.com/2014/11/add-uitableview-programmatically-in.html
//  URL:  https://www.murage.ca/downcasting-in-swift-1-2-with-as-exclamation/
//  URL:  http://www.tutorialspoint.com/ios/ios_ui_elements_tableview.htm
//


import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var verbose : Bool = false;

    let numItems_init  : Int = 25;
    
    var items: [String]!;
    
    var tableView          : UITableView!;
    var customTable        : UICustomTableView!;
    var customTableHandler : UICustomTableViewHandler!;
    
    //options
    var cellBordersVisible : Bool = true;
    var usesCustomTiles    : Bool = false;
    
    //std table config
    let cellSelectionFade : Bool = true;

    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.view.translatesAutoresizingMaskIntoConstraints = false;

        self.loadItems();
        
        if(usesCustomTiles == true) {
            self.addCustomTable();
        } else {
            self.addStandardTable();
        }
        
        //Exit
        if(verbose){ print("ViewController.viewDidLoad():       viewDidLoad() complete"); }

        return;
    }


    func addCustomTable() {
    
        if(verbose){ print("ViewController.addCustomTable():      adding a custom table"); }
        
        customTable = UICustomTableView(frame:self.view.frame, style:UITableViewStyle.Plain, items:items);

        //add the handler
        customTableHandler = UICustomTableViewHandler(items: items, timerTable: customTable);

        customTable.delegate   = customTableHandler;                                            //Set both to handle clicks & provide data
        customTable.dataSource = customTableHandler;
        
        //init the table
        customTable.separatorColor = (cellBordersVisible) ? .greenColor() : .clearColor();
        customTable.separatorStyle = (cellBordersVisible) ? .SingleLine : .None;
        
        //Safety
        customTable.backgroundColor = UIColor.blackColor();
        
        //Set the row height
        customTable.rowHeight = 75;
     
        if(verbose){ print("ViewController.addCustomTable():      it was shown"); }
        
        self.view.addSubview(customTable);
        
        return;
    }
    
    
    func addStandardTable() {

        if(verbose){ print("ViewController.addStandardTable():      adding a standard table"); }

        //Init
        tableView = UITableView(frame:self.view.frame);

        tableView.delegate = self;                                                              //Set both to handle clicks & provide data
        tableView.dataSource = self;

        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell");          //I have no idea why we do this
        tableView.translatesAutoresizingMaskIntoConstraints = false;                            //Std

        tableView.separatorColor = (cellBordersVisible) ? .greenColor() : .clearColor();
        tableView.separatorStyle = (cellBordersVisible) ? .SingleLine : .None;

        //Safety
        tableView.backgroundColor = UIColor.blackColor();

        //Set the row height
        tableView.rowHeight = 75;

        if(verbose){ print("ViewController.addStandardTable():      it was shown"); }

        //Add it!
        self.view.addSubview(tableView);

        return;
    }


/****************************************************************************************************************************************/
/*                                                         Helpers                                                                      */
/****************************************************************************************************************************************/
    func loadItems() {

        if(verbose){ print("ViewController.loadItems():    Items are loaded"); }
        
        items = [String]();
        
        for(var i:Int=0; i<self.numItems_init; i++) {
            
            let charName : String = self.getCharName(i);
            
            items.append(self.getRowLabel(charName, index: i));
        }
        
        return;
    }
    
    
    func getCharName(i : Int) -> String {
        return String(UnicodeScalar(i + Int(("A" as UnicodeScalar).value)));
    }
    
    
    func getRowLabel(charName : String, index: Int) -> String {
        return String(format: "Item '%@' (%d)", charName, index);
    }
    
    
    func addNewRow() {
        
        let charName : String = self.getCharName(items.count);
        
        items.append(self.getRowLabel(charName, index: items.count));

        tableView.reloadData();
        
        print("row was added '\(items[items.count-1])'");
        
        return;
    }
    
    
/****************************************************************************************************************************************/
/*                                      UITableViewDataSource, UITableViewDelegate Interfaces                                           */
/****************************************************************************************************************************************/
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(verbose){ print("ViewController.tableView():         The table will now have \(items.count), cause I just said so..."); }
        
        return items.count;                                                         //return how many rows you want printed....!
    }

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        if(verbose){ print("ViewController.tableView():         adding a cell"); }

        let cell = tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell!;
        
        let newTextValue:String = self.items[indexPath.row];
        
        cell.textLabel?.text = newTextValue;                                                //text
        cell.textLabel?.font = UIFont(name: cell.textLabel!.font.fontName, size: 20);       //font
        cell.textLabel?.textAlignment = NSTextAlignment.Center;                             //alignment
        
        
        if(self.cellSelectionFade == true) {
            cell.selectionStyle = UITableViewCellSelectionStyle.Gray;   //Options are 'Gray/Blue/Default/None'
        } else {
            cell.selectionStyle = UITableViewCellSelectionStyle.None;
        }


        
        if(verbose){ print("'\(newTextValue)' was added to the table"); }
        
        return cell;
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        if(verbose){ print("ViewController.tableView():         handling a cell tap of \(indexPath.item)"); }

        tableView.deselectRowAtIndexPath(indexPath, animated:true);

        let currCell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell!;
        
        if(verbose){ print("Hello Standard Cell at index \(indexPath)- '\(currCell.textLabel!.text)'"); }

        
        
        /********************************************************************************************************************************/
        /* scroll to the top or change the bar color                                                                                    */
        /********************************************************************************************************************************/
        switch(indexPath.row) {
        case (0):
            print("top selected. Scrolling to the bottom!");
            tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: items.count-1, inSection: 0), atScrollPosition: UITableViewScrollPosition.Bottom, animated: true);
            break;
        case (1):
            print("scrolling to the top with a Rect and fade");
            tableView.scrollRectToVisible(CGRectMake(0,0,1,1), animated:true);           //slow scroll to top
            break;
        case (2):
            print("scrolling to the top with a Rect and no fade");
            tableView.scrollRectToVisible(CGRectMake(0,0,1,1), animated:false);          //immediate scroll to top
            break;
        case (3):
            print("scrolling to the top with scrollToRowAtIndexPath");
            tableView.scrollToRowAtIndexPath(NSIndexPath(forRow: 0, inSection: 0), atScrollPosition: UITableViewScrollPosition.Top, animated: true);
            break;
        case(4):
            print("adding a new row");
            self.addNewRow();
            break;
        default:
            print("I didn't program a reaction for this case. I was lazy...");
            break;
        }
        
        return;
    }
    
    
    override func didReceiveMemoryWarning() { super.didReceiveMemoryWarning(); }
}

