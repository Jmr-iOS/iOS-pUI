//
//  ViewController.swift
//  0_0 - UIView
//
//  URL(animations): http://www.raywenderlich.com/76200/basic-uiview-animation-swift-tutorial
//  URL(animations): http://www.raywenderlich.com/86521/how-to-make-a-view-controller-transition-animation-like-in-the-ping-app
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {

    var viewOne   : UIView!;
    var viewTwo   : UIView!;
    var viewThree : UIView!;
    
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        self.genBasicViews();
        self.genUpperBorderedView();

        self.add_primary_tapResponse();
        
        return;
    }
    
    
    func genBasicViews() {
        
        self.viewOne = UIView();
        self.viewOne.backgroundColor = UIColor.redColor();
        self.viewOne.frame = self.view.frame;

        self.addSecondUIView(viewOne, dispStr: "View 1");
        self.addSubviewButton(viewOne, return_msg: "Launch View #2", action_fcn:  #selector(ViewController.press_launch(_:)));

        self.viewTwo = UIView();
        self.viewTwo.backgroundColor = UIColor.blueColor();
        self.viewTwo.frame = self.view.frame;

        self.addSecondUIView(viewTwo, dispStr: "View 2");
        self.addSubviewButton(viewTwo, return_msg: "Return to View #1", action_fcn:  #selector(ViewController.press_return(_:)));

        self.viewOne.frame = self.view.frame;
        self.viewTwo.frame = CGRectMake(self.view.frame.width,
                                        0,
                                        self.view.frame.width,
                                        self.view.frame.height);       //init off-screen
        
        self.view.addSubview(self.viewOne);                                    //add em both!
        self.view.addSubview(self.viewTwo);
        
        return;
    }


    func genUpperBorderedView() {

        
        //Generate the View
        self.viewThree = UIView();
        self.viewThree.backgroundColor = UIColor.whiteColor();
        self.viewThree.frame = CGRectMake(100, 300, 200, 150);

        self.view.addSubview(self.viewThree);

        
        //Generate an upper border for the View (1 pixel tall)
        let upperBorder : CALayer = CALayer();
        
        upperBorder.frame = CGRectMake(0, 0, self.viewThree.frame.width, 1);
        
        upperBorder.backgroundColor = UIColor(red:   140/255,                               /* Apple border color                   */
                                              green: 140/255,
                                              blue:  140/255,
                                              alpha: 1.0).CGColor;
        //Add border
        self.viewThree.layer.addSublayer(upperBorder);          /* note - it could be added to self.view.layer instead if desired   */
        
        
        return;
    }
    
    
    func pick_view(showFirst: Bool) {

        if(!showFirst) {
            self.view.addSubview(viewTwo);
        }

        print("old view off!");
        
        let animDur_s : Double = 0.5;
        let animDel_s : Double = 0.5;
        
        UIView.animateWithDuration(animDur_s, delay: animDel_s, options: UIViewAnimationOptions.TransitionCrossDissolve, animations: {
            
            if(!showFirst) {                    /* Slide View 2 into view                                                           */
                print("sliding view 2 in!");
                self.viewTwo.alpha = 1.0;
                self.viewTwo.frame = self.view.frame;
                
            } else {                            /* Slide View 2 out of view                                                         */
                print("sliding view 2 out!");
                self.viewOne.frame = self.view.frame;
                self.viewTwo.frame = CGRectMake(self.view.frame.width,
                                                0,
                                                self.view.frame.width,
                                                self.view.frame.height);       /* init off-screen                                   */
                
            
            }
        }, completion: { (finished: Bool) -> Void in

            if(!showFirst) {                    /* Slide View 2 into view                                                           */
                print("sliding view 2 in completion!");
                
                self.viewOne.frame = CGRectMake(0, 0, self.view.frame.width, self.view.frame.height);
                
            } else {                            /* Slide View 2 out of view                                                         */
                print("sliding view 2 out completion!");
                
                self.viewTwo.frame = CGRectMake(self.view.frame.width, 0, self.view.frame.width, self.view.frame.height); //TEMP
            }
        });
        
        return;
    }
    
    
    func add_primary_tapResponse() {

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(ViewController.myPrimaryTapResponse(_:)));
        
        tapGesture.delegate = self;
        
        self.view.addGestureRecognizer(tapGesture);
        
        return;
    }
    
    
    func addSecondUIView(aView: UIView, dispStr : String) {

        let anotherView : UIView = UIView(frame: CGRect(x: 20, y:60, width: 100, height: 50));
        
        anotherView.backgroundColor = UIColor.grayColor();
        
        anotherView.layer.cornerRadius = 15;

        let someLabel : UILabel = UILabel(frame: CGRect(x:5, y: 0, width: anotherView.frame.width, height:  anotherView.frame.height));
    
        someLabel.font  =   UIFont(name: "HelveticaNeue", size: 23);
        someLabel.text  =   dispStr;
        someLabel.textColor     = UIColor.whiteColor();
        someLabel.textAlignment = NSTextAlignment.Center;
    
        anotherView.addSubview(someLabel);
        
        aView.addSubview(anotherView);
    
        return;
    }
    
    
    func addSubviewButton(aView: UIView, return_msg: String, action_fcn : Selector) {
        
        let newButton : UIButton = UIButton(type: UIButtonType.RoundedRect);
        
        newButton.translatesAutoresizingMaskIntoConstraints = true;                     /* must be true for center to work          */

        newButton.setTitle(return_msg,      forState: UIControlState.Normal);
        newButton.backgroundColor = UIColor.whiteColor();
        
        //newButton.frame = CGRectMake(0, 0, 144, 30);                                  /* or just use sizeToFit(), it's easier!    */
        newButton.sizeToFit();
        newButton.center = CGPointMake((UIScreen.mainScreen().bounds.width)/2, 250);    /* must call after it's sized or won't work!*/
        
        //actions
        newButton.addTarget(self, action: action_fcn, forControlEvents:  .TouchUpInside);
        
        //add!
        aView.addSubview(newButton);
        
        return;
    }
    
/*
     // Add tap gesture recognizer to View
     let tapGesture = UITapGestureRecognizer(target: self, action: Selector("myMethodToHandleTap:"))
     tapGesture.delegate = self
     myView.addGestureRecognizer(tapGesture)
     }

     func myMethodToHandleTap(sender: UITapGestureRecognizer) {

     let tappedView = sender.view as! UIView
     // ...
     }
*/

    func myPrimaryTapResponse(sender: UITapGestureRecognizer) {
        
        print("Bam here it is!!!!");
        //let tappedView = sender.view as UIView!;

        return;
    }
    
    
    func press_launch(sender: UIButton!) {

        print("\(sender.titleLabel!.text!) was pressed and press_launch called");

        self.pick_view(false);

        return;
    }

    
    func press_return(sender: UIButton!) {
        print("\(sender.titleLabel!.text!) was pressed and press_return called");
        
        self.pick_view(true);

        return;
    }

    
    override func didReceiveMemoryWarning() { super.didReceiveMemoryWarning(); }
}

