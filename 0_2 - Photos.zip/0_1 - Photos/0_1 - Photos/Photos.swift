/************************************************************************************************************************************/
/** @class      Photos
 *  @proj       0_1- Photos
 *  @brief      x
 *  @details    x
 *
 *  @auth       Created by Justin Reina on 11/11/17
 *  @cpr        Copyright © 2017 Jmr. All rights reserved
 *
 *
 *  @section     Opens
 *      Access Photo Library
 */
/************************************************************************************************************************************/
import UIKit
import MediaPlayer


class Photos: NSObject {

    //Library Vars
    //x
    
    //Parse Pictures
    //x

    
    /********************************************************************************************************************************/
    /** @fcn        override init()                                                                                                 */
    /*  @brief      x                                                                                                               */
    /********************************************************************************************************************************/
    override init() {
        super.init();
        return;
    }
    
    /********************************************************************************************************************************/
    /** @fcn        func getPhotos()
     *  @brief      Access the photo library
     *  @details    x
     *
     *  @ref    https://medium.com/@abhimuralidharan/accessing-photos-in-ios-swift-3-43da29ca4ccb
     */
    /********************************************************************************************************************************/
    func getPhotos() {
        
        print("Getting photos");
        
        let _/*imagePicker*/ : UIImagePickerController = UIImagePickerController();
     
        print("Todo. See @ref, this has a lot of steps and permissions!");
        
        return;
    }
}

