/************************************************************************************************************************************/
/** @file       BatteryMonitor.swift
 *  @project    0_2 - Statistics
 *  @brief      x
 *  @details    x
 *
 *  @ref    https://stackoverflow.com/questions/27475506/check-battery-level-ios-swift
 *
 *  @section    Opens
 *      none current
 *
 * @section    Legal Disclaimer
 *      All contents of this source file and/or any other Jaostech related source files are the explicit property on Jaostech
 *      Corporation. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
import UIKit


public class BatteryMonitor : NSObject {
    
    /********************************************************************************************************************************/
    /** @fcn        override init()
     *  @brief      x
     *  @details    x
     */
    /********************************************************************************************************************************/
    override init() {
        super.init();

        //Enable Battery Monitoring
        UIDevice.current.isBatteryMonitoringEnabled = true;
        print("Current Battery Level - \(UIDevice.current.batteryLevel*100)%");
        
        return;
    }
    
    
    /********************************************************************************************************************************/
    /** @fcn        class func getBatteryLevel() -> Float
     *  @brief       read current battery level
     *
     *  @param        [out] (Float) battery level (0-100)
     */
    /********************************************************************************************************************************/
    class func getBatteryLevel() -> Float {

        //Enable Battery Monitoring
        UIDevice.current.isBatteryMonitoringEnabled = true;
        
        let battLvl : Float = UIDevice.current.batteryLevel;
        
        if(battLvl == -1) {
            return nan("unknown value");
        } else {
            return battLvl*100;
        }
    }
}

